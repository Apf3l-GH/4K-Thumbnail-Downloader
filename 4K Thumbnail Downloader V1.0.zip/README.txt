			INSTALLATION:

1. you need to have Python 3 Installed 
(If you dont have it, you can download it here: https://www.python.org/downloads/windows/)

2. Unpack the ZIP-File and run INSTALL.py 

		               Installation flinished!