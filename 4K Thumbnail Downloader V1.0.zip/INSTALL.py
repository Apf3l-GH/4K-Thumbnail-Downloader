import shutil
import os

fpath = __file__[0:-10]
print(fpath)
path = fpath + "4K Thumbnail Downloader Data"
print(path)

destination = "C:\\"

shutil.move(path,destination)

shutil.move(__file__,r"C:\4K Thumbnail Downloader Data")

Desktop = "C:\\Users\\" + os.getlogin() + r"\Desktop"

shutil.move(r"C:\4K Thumbnail Downloader Data\4K Thumbnail Downloader.lnk",Desktop)

path2 = open(r"C:\4K Thumbnail Downloader Data\path.txt",'w')
path3 = path2.write("")

shutil.move(fpath + r"\README.txt",r"C:\4K Thumbnail Downloader Data")

pathdesktop2 = open(r"C:\4K Thumbnail Downloader Data\path.txt",'w')
pathdesktop = pathdesktop2.write(Desktop)