import urllib.request
import os

slash = "/"
path2 = open(r"C:\4K Thumbnail Downloader Data\path.txt",'r')
path = path2.read()
about2 = open(r"C:\4K Thumbnail Downloader Data\about.txt",'r')
about = about2.read()
langpath = open(r"C:\4K Thumbnail Downloader Data\lang.txt",'r')
langpath2 = langpath.read() 

if langpath2 == "de":
    lang1 = "de"
    
elif langpath2 == "en":
    lang1 = "en"
    

else:
    langinput = input("1) English\n2) Deutsch\n Please select your language: ")

    langpath3 = open(r"C:\4K Thumbnail Downloader Data\lang.txt",'w+')

    if langinput == "2":
        langpath3.write("de")
    elif langinput == "1":
        langpath3.write("en")
    else:
        print("")
     


if lang1 == "en":
    lngoptionsinptxt = "1) Change Download folder\n2) Change Language\n3) About\n4) Changelog\n5) Go Back to the Home menu\n\n"
    lngbittelinkeingeben = "Please enter the YouTube link: "
    lngBitteSpeicherorteingeben = "Please Enter the Download location: "
    lngspeicherortgeändert = "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nDownload Location has been changed!\n\nPress any key to close the programm: "
    lngCurrent_Path = "Current Folder: "
else:
    lngoptionsinptxt = "1) Ändere den Download Ordner\n2) Ändere die Sprache\n3) About\n4) Changelog\n5) Zurück zum Hauptmenü\n\n"
    lngbittelinkeingeben = "Bitte Link eingeben: "
    lngBitteSpeicherorteingeben = "Bitte Speicherort Eingeben: "
    lngspeicherortgeändert = "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nDer Speicherort wurde erfolgreich geändert!\n\nDrücke eine beliebige Taste um das Programm zu beenden: "
    lngCurrent_Path = "Momentaner Ordner: "


if lang1 == "en":
    print("Version 1.1                                    ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                     ═══════════════════════════════════════════")
    print("                                     ║          4K Thumbnail Downloader        ║")
    print("                                     ║                 by Apf3l_               ║")
    print("                                     ═══════════════════════════════════════════")
    print("                                          ║     Enter s for Settings      ║     ")
    print("                                          ═════════════════════════════════     ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")

else:
    print("Version 1.1                                    ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                     ═══════════════════════════════════════════")
    print("                                     ║          4K Thumbnail Downloader        ║")
    print("                                     ║                 by Apf3l_               ║")
    print("                                     ═══════════════════════════════════════════")
    print("                                          ║  Schreibe s für Einstellungen ║     ")
    print("                                          ═════════════════════════════════     ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")

rawlink = input(lngbittelinkeingeben) 


if rawlink == "s":
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                     ═══════════════════════════════════════════")
    print("                                     ║          4K Thumbnail Downloader        ║")
    print("                                     ║                 by Apf3l_               ║")
    print("                                     ═══════════════════════════════════════════")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    print("                                               ")
    options = input(lngoptionsinptxt)
    if options == "1":
        datei = open(r"C:\4K Thumbnail Downloader Data\path.txt",'w+')
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                     ═══════════════════════════════════════════")
        print("                                     ║          4K Thumbnail Downloader        ║")
        print("                                     ║                 by Apf3l_               ║")
        print("                                     ═══════════════════════════════════════════")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        
        print(lngCurrent_Path + path + "\n")
        input2 = input(lngBitteSpeicherorteingeben)
        datei.write(input2)
        print(lngspeicherortgeändert)
        os.system("pause")
    elif options == "2":
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                     ═══════════════════════════════════════════")
        print("                                     ║          4K Thumbnail Downloader        ║")
        print("                                     ║                 by Apf3l_               ║")
        print("                                     ═══════════════════════════════════════════")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        print("                                               ")
        
        langinput = input("1) English\n2) Deutsch\n\nPlease select your language: ")

        langpath3 = open(r"C:\4K Thumbnail Downloader Data\lang.txt",'w+')

        if langinput == "2":
            langpath3.write("de")
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nDie Sprache wurde erfolgreich geändert!\n\nDrücke eine beliebige Taste um das Programm zu beenden: ")
            os.system("pause")
        elif langinput == "1":
            langpath3.write("en")
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nLanguage has been changed!\n\nPress any key to close the programm: ")
            os.system("pause")
        elif langinput == "3":
            print("Wait... Thats illegal\n")
            os.system("pause")
            os.system("python thumbnaildownload.py")
        elif langinput == "4":
            print("Stop trying\n")
            os.system("pause")
            os.system("python thumbnaildownload.py")
        elif langinput == "5":
            print("I said stop\n")
            os.system("pause")
            os.system("python thumbnaildownload.py")
        else:
            print("")
    
    elif options == "3":
        print(about)
        os.system("pause")
        os.system("python thumbnaildownload.py")
    elif options == "4":
        print("- Fixed Installer\n- Added this Changelog section")
        os.system("pause")
        os.system("python thumbnaildownload.py")
    elif options == "5":
        os.system("python thumbnaildownload.py")
        exit()
    else:
        exit()
else: 
    ID = rawlink[32:43] 
    link1 = "https://i.ytimg.com/vi/"
    link2 = "/maxresdefault.jpg"

    link = link1+ID+link2

    save2 = ".jpg"
    save = path+slash+ID+save2
    
    print("Downloading...")
    urllib.request.urlretrieve(link, save)

